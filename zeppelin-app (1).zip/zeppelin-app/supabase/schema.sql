-- Zeppelin: estoque, caixa, clientes e pedidos.
-- Cole este arquivo inteiro no SQL Editor do Supabase e clique em Run.

-- ============ TABELAS ============

create table if not exists public.produtos (
  id          uuid primary key default gen_random_uuid(),
  nome        text not null,
  categoria   text not null default '',
  preco       numeric(12,2) not null default 0 check (preco >= 0),
  custo       numeric(12,2) not null default 0 check (custo >= 0),
  estoque     integer not null default 0 check (estoque >= 0),
  minimo      integer not null default 0 check (minimo >= 0),
  created_at  timestamptz not null default now()
);

create table if not exists public.clientes (
  id          uuid primary key default gen_random_uuid(),
  nome        text not null,
  telefone    text not null default '',
  cidade      text not null default '',
  endereco    text not null default '',
  obs         text not null default '',
  created_at  timestamptz not null default now()
);

create table if not exists public.pedidos (
  id                uuid primary key default gen_random_uuid(),
  numero            bigint generated always as identity unique,
  cliente_id        uuid references public.clientes(id) on delete set null,
  cliente_nome      text not null default '',
  itens             jsonb not null default '[]'::jsonb,
  desconto          numeric(12,2) not null default 0 check (desconto >= 0),
  subtotal          numeric(12,2) not null default 0,
  total             numeric(12,2) not null default 0,
  forma             text not null check (forma in ('Dinheiro','Pix','Cartão','Fiado')),
  status            text not null check (status in ('pago','pendente','cancelado')),
  obs               text not null default '',
  entrega_tipo      text not null default 'Retirada' check (entrega_tipo in ('Retirada','Entrega')),
  entrega_endereco  text not null default '',
  entrega_taxa      numeric(12,2) not null default 0 check (entrega_taxa >= 0),
  entregue          boolean not null default false,
  criado            timestamptz not null default now(),
  pago_em           timestamptz,
  cancelado_em      timestamptz
);

create table if not exists public.caixa (
  id          uuid primary key default gen_random_uuid(),
  tipo        text not null check (tipo in ('entrada','saida')),
  valor       numeric(12,2) not null check (valor > 0),
  descricao   text not null default '',
  forma       text not null default '',
  pedido_id   uuid references public.pedidos(id) on delete set null,
  criado      timestamptz not null default now()
);

-- Configurações da loja (dados da loja, logo, categorias, aparência)
create table if not exists public.config (
  chave  text primary key,
  valor  jsonb not null default '{}'::jsonb
);

create index if not exists pedidos_criado_idx  on public.pedidos (criado desc);
create index if not exists pedidos_status_idx  on public.pedidos (status);
create index if not exists pedidos_cliente_idx on public.pedidos (cliente_id);
create index if not exists caixa_criado_idx    on public.caixa (criado desc);
create index if not exists produtos_cat_idx    on public.produtos (categoria);

-- ============ SEGURANÇA (RLS) ============
-- Só usuários logados (criados por você em Authentication > Users) leem e gravam.

alter table public.produtos enable row level security;
alter table public.clientes enable row level security;
alter table public.pedidos  enable row level security;
alter table public.caixa    enable row level security;
alter table public.config   enable row level security;

do $$
declare t text;
begin
  foreach t in array array['produtos','clientes','pedidos','caixa','config'] loop
    execute format('drop policy if exists "equipe acessa tudo" on public.%I', t);
    execute format(
      'create policy "equipe acessa tudo" on public.%I for all to authenticated using (true) with check (true)', t);
  end loop;
end $$;

-- ============ FUNÇÕES (operações que mexem em várias tabelas de uma vez) ============

-- Cria o pedido, baixa o estoque e lança a entrada no caixa, tudo ou nada.
-- Preço e custo vêm do cadastro do produto; o total é calculado aqui.
create or replace function public.criar_pedido(p jsonb)
returns public.pedidos
language plpgsql
security invoker
set search_path = public
as $$
declare
  it        jsonb;
  v_nome    text;
  v_preco   numeric(12,2);
  v_custo   numeric(12,2);
  v_qtd     integer;
  v_itens   jsonb := '[]'::jsonb;
  v_sub     numeric(12,2) := 0;
  v_desc    numeric(12,2) := coalesce(nullif(p->>'desconto','')::numeric, 0);
  v_tipo    text := coalesce(nullif(p->>'entrega_tipo',''), 'Retirada');
  v_taxa    numeric(12,2) := 0;
  v_forma   text := p->>'forma';
  v_status  text;
  v_total   numeric(12,2);
  v_cli_id  uuid := nullif(p->>'cliente_id','')::uuid;
  v_cli     text := '';
  v_ped     public.pedidos;
begin
  if jsonb_typeof(p->'itens') is distinct from 'array' or jsonb_array_length(p->'itens') = 0 then
    raise exception 'Pedido sem itens';
  end if;
  if v_forma is null or v_forma not in ('Dinheiro','Pix','Cartão','Fiado') then
    raise exception 'Forma de pagamento inválida';
  end if;
  if v_tipo = 'Entrega' then
    v_taxa := coalesce(nullif(p->>'entrega_taxa','')::numeric, 0);
  end if;
  if v_cli_id is not null then
    select nome into v_cli from public.clientes where id = v_cli_id;
    v_cli := coalesce(v_cli, '');
  end if;

  for it in select * from jsonb_array_elements(p->'itens') loop
    v_qtd := (it->>'qtd')::integer;
    if v_qtd is null or v_qtd <= 0 then
      raise exception 'Quantidade inválida';
    end if;

    select nome, preco, custo into v_nome, v_preco, v_custo
      from public.produtos where id = (it->>'pid')::uuid for update;
    if not found then
      raise exception 'Produto não encontrado';
    end if;

    update public.produtos
       set estoque = estoque - v_qtd
     where id = (it->>'pid')::uuid and estoque >= v_qtd;
    if not found then
      raise exception 'Estoque insuficiente para %', v_nome;
    end if;

    v_sub   := v_sub + v_qtd * v_preco;
    v_itens := v_itens || jsonb_build_object(
      'pid', it->>'pid', 'nome', v_nome, 'qtd', v_qtd, 'preco', v_preco, 'custo', v_custo);
  end loop;

  v_total  := greatest(v_sub - v_desc, 0) + v_taxa;
  v_status := case when v_forma = 'Fiado' then 'pendente' else 'pago' end;

  insert into public.pedidos (
    cliente_id, cliente_nome, itens, desconto, subtotal, total, forma, status, obs,
    entrega_tipo, entrega_endereco, entrega_taxa, pago_em)
  values (
    v_cli_id, v_cli, v_itens, v_desc, v_sub, v_total, v_forma, v_status, coalesce(p->>'obs',''),
    v_tipo, case when v_tipo = 'Entrega' then coalesce(p->>'entrega_endereco','') else '' end, v_taxa,
    case when v_status = 'pago' then now() end)
  returning * into v_ped;

  if v_status = 'pago' and v_total > 0 then
    insert into public.caixa (tipo, valor, descricao, forma, pedido_id)
    values ('entrada', v_total,
            'Pedido #' || v_ped.numero || case when v_cli <> '' then ' · ' || v_cli else '' end,
            v_forma, v_ped.id);
  end if;

  return v_ped;
end;
$$;

-- Recebe um pedido que estava como fiado e lança a entrada no caixa.
create or replace function public.receber_pedido(p_id uuid, p_forma text)
returns public.pedidos
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_ped public.pedidos;
begin
  if p_forma is null or p_forma not in ('Dinheiro','Pix','Cartão') then
    raise exception 'Forma de pagamento inválida';
  end if;

  update public.pedidos
     set status = 'pago', forma = p_forma, pago_em = now()
   where id = p_id and status = 'pendente'
  returning * into v_ped;
  if not found then
    raise exception 'Este pedido não está a receber';
  end if;

  if v_ped.total > 0 then
    insert into public.caixa (tipo, valor, descricao, forma, pedido_id)
    values ('entrada', v_ped.total, 'Recebimento pedido #' || v_ped.numero, p_forma, v_ped.id);
  end if;

  return v_ped;
end;
$$;

-- Cancela o pedido, devolve o estoque e, se já estava pago, lança o estorno no caixa.
create or replace function public.cancelar_pedido(p_id uuid)
returns public.pedidos
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_ped public.pedidos;
  v_new public.pedidos;
  it    jsonb;
begin
  select * into v_ped from public.pedidos where id = p_id for update;
  if not found then
    raise exception 'Pedido não encontrado';
  end if;
  if v_ped.status = 'cancelado' then
    raise exception 'Este pedido já foi cancelado';
  end if;

  for it in select * from jsonb_array_elements(v_ped.itens) loop
    update public.produtos
       set estoque = estoque + (it->>'qtd')::integer
     where id = (it->>'pid')::uuid;
  end loop;

  update public.pedidos
     set status = 'cancelado', cancelado_em = now()
   where id = p_id
  returning * into v_new;

  if v_ped.status = 'pago' and v_ped.total > 0 then
    insert into public.caixa (tipo, valor, descricao, forma, pedido_id)
    values ('saida', v_ped.total, 'Estorno pedido #' || v_ped.numero, v_ped.forma, v_ped.id);
  end if;

  return v_new;
end;
$$;

revoke all on function public.criar_pedido(jsonb)        from public, anon;
revoke all on function public.receber_pedido(uuid,text)  from public, anon;
revoke all on function public.cancelar_pedido(uuid)      from public, anon;
grant execute on function public.criar_pedido(jsonb)        to authenticated;
grant execute on function public.receber_pedido(uuid,text)  to authenticated;
grant execute on function public.cancelar_pedido(uuid)      to authenticated;

-- ============ TEMPO REAL (a tela atualiza quando outra pessoa altera algo) ============
do $$
declare t text;
begin
  foreach t in array array['produtos','clientes','pedidos','caixa','config'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;
